import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
import os
import time
import sys
import random
import numpy as np

def create_model(p, p_name, factor, endt):

    mdl = Model()
    r = ReactionManager()

    # Diffusionskonstanten

    #DCR = p["DCR"]#2.5e-14 # m^2/s
    DC = p["DC"]#7e-12  # m^2/s


    #Faktor für Reaktionsraten
    c1 = 1
    c2 = 1

    with mdl:
        vsys = VolumeSystem.Create()
        exo_vsys = VolumeSystem.Create()
        vsys_nuc = VolumeSystem.Create()
        ssys = SurfaceSystem.Create()

        EGF, EGFR, EGF_EGFR, EGF_EGFR2, EGF_EGFRp2, GAP, EGF_EGFRp2_GAP, ERK, ERKp, ERKpp, P3  = Species.Create()

        with vsys:
            # ERK Deaktivierung
            ERKp + P3 > r[6] > ERK + P3
            r[6].K = p["k[666]"]
            #Cytoplasm diffusion
            Diffusion(ERK, DC)
            Diffusion(ERKp, DC)
            Diffusion(P3, 2*DC)
            Diffusion(GAP, DC/4)

        with exo_vsys:
            Diffusion(EGF, DC/10)

        with vsys_nuc:
            ERKp > r[7] > ERKpp
            r[7].K = 1e8
            Diffusion(ERKpp, DC)

        with ssys:
            EGFR.s + EGF.o < r[1] > EGF_EGFR.s
            EGF_EGFR.s + EGF_EGFR.s < r[2] > EGF_EGFR2.s
            EGF_EGFR2.s < r[3] > EGF_EGFRp2.s
            EGF_EGFRp2.s + GAP.i < r[4] > EGF_EGFRp2_GAP.s
            # None > r[13] > EGFR.s
            EGF_EGFRp2_GAP.s + ERK.i < r[5] > EGF_EGFRp2_GAP.s + ERKp.i
            r[1].K = 3e7, 38e-4   # 1/Ms
            r[2].K = 1e7 * 100, 0.1   # 1/Ms
            r[3].K = 1 * 100, 0.01  # 1/s
            r[4].K = 1e6 * 100 , 0.2   # 1/Ms 1e6, 0.2
            r[5].K = p["k[0]"], 0.1 #1e8 * c1, 0.1 * c1
            Diffusion(EGFR, DC/10)
            Diffusion(EGF_EGFR, DC/20)
            Diffusion(EGF_EGFR2, DC/40)
            Diffusion(EGF_EGFRp2, DC/40)
            Diffusion(EGF_EGFRp2_GAP, DC/50)

    # Mesh
    if os.getcwd() != '/home/anna3171/annas-magnificent-steps-project':

        os.chdir(r"/home/anna3171/annas-magnificent-steps-project")

    ## Kugel mit Radius 12 und max.size 0.4
    mesh = TetMesh.LoadAbaqus('meshes/kugel_7.5-ext.inp', scale = 10**(-6))

    #für Sphere
    #Volume1 --> exo
    #Volume2 --> cyt
    #Volume3 --> nuc

    with mesh:

    # LISTEN

        #Exo
        exo_tets = TetList(mesh.tetGroups["Volume1"])

        #Zelle
        cyt_tets = TetList(mesh.tetGroups["Volume2"])

        #Zellkern
        nuc_tets = TetList(mesh.tetGroups["Volume3"])


        #TETS im Cyt, die an die Membran grenzen
        mem_tris = cyt_tets.surface
        mem_tet = TetList()
        for tri in mem_tris:
           for tet in tri.tetNeighbs:
                mem_tet.append(tet)
        mem_tet = TetList([tet for tet in mem_tet if tet in cyt_tets])

        #Hälfte Cyto
        half_cyt = TetList(tet for tet in cyt_tets if tet.center.z > 0)
        #TRIS vom Durchschnitt
        slice_cyt = TriList(half_cyt.surface & (cyt_tets - half_cyt).surface)
        # die Tets am Querschnitt
        slice_tet_cyt = TetList()
        triInds_cyt = []
        for tri in slice_cyt:
            for tet in tri.tetNeighbs:
                slice_tet_cyt.append(tet)
                triInds_cyt.append(tri.idx)

        #Häfte Nuc
        half_nuc = TetList(tet for tet in nuc_tets if tet.center.z > 0)
        #TRIS vom Durchscnitt
        slice_nuc = TriList(half_nuc.surface & (nuc_tets - half_nuc).surface)
        # die Tets am Querschnitt
        slice_tet_nuc = TetList()
        triInds_nuc = []
        for tri in slice_nuc:
            for tet in tri.tetNeighbs:
                slice_tet_nuc.append(tet)
                triInds_nuc.append(tri.idx)

        # for Signal in ext
        tips = TetList(tet for tet in exo_tets if np.linalg.norm(tet.center) > 20e-6)
        tips_one = TetList(tet for tet in tips if tet.center.z < 0)

    # COMPARTMENTS

        # Zellkern
        nuc = Compartment.Create(nuc_tets, vsys_nuc)

        # Cytoplasma
        cyt = Compartment.Create(cyt_tets, vsys)

        # Zelläüßeres
        exo = Compartment.Create(exo_tets, exo_vsys)

        # Zellmembran
        cell_surface = Patch.Create(cyt.surface & exo.surface, cyt, exo, ssys)

    #DIFFUSIONS BARRIERE

        #Zellkernmembran
        nuc_mem = DiffBoundary.Create(nuc.surface)

    ratio_v = exo.Vol / 1286e-18

    seed = random.randint(1,6000)

    rng = RNG("mt19937", 512, seed)
    sim = Simulation('Tetexact', mdl, mesh, rng)
    rs = ResultSelector(sim)

    EGF_EGFR_Count = rs.SUM(rs.TRIS(cell_surface.tris).EGF_EGFR.Count)
    EGF_EGFR2_Count = rs.SUM(rs.TRIS(cell_surface.tris).EGF_EGFR2.Count)
    EGF_EGFRp2_Count = rs.SUM(rs.TRIS(cell_surface.tris).EGF_EGFRp2.Count)
    EGF_EGFRp2_GAP_Count = rs.SUM(rs.TRIS(cell_surface.tris).EGF_EGFRp2_GAP.Count)
    ERKp_Count = rs.SUM(rs.TETS(cyt_tets).ERKp.Count)#rs.TETS(cell_tets).Xa.Count
    #Xa_Origin = rs.TETS(mem_tet).Xa.Count
    ERKpp_Count = rs.SUM(rs.TETS(nuc_tets).ERKpp.Count)
    #slice_ERKp = rs.TETS(slice_tet_cyt).ERKp.Count
    #slice_ERKpp = rs.TETS(slice_tet_nuc).ERKpp.Count
    #surf_rec_com = rs.TRIS(cell_surface.tris).EGF_EGFRp2_GAP.Count

    #meta data
    #Xa_Origin.metaData['distToCenter'] = [np.linalg.norm(tet.center) for tet in mem_tet]
    #Xa_Count.metaData['Vol'] = [tet.Vol for tet in cell_tets]
    #Xa_Count.metaData["center_x"] = [tet.center.x for tet in cell_tets]
    #Xa_Count.metaData["center_y"] = [tet.center.y for tet in cell_tets]
    #Xa_Count.metaData["center_z"] = [tet.center.z for tet in cell_tets]
    #slice_ERKp.metaData['surfTri'] = triInds_cyt #for plottting
    #slice_ERKpp.metaData["surfTri"] = triInds_nuc
    #surf_rec_com.metaData["dist"] = [np.linalg.norm(tri.center) for tri in cell_surface.tris]
    #surf_rec_com.metaData["area"] = [tri.Area for tri in cell_surface.tris]

    sim.toSave(EGF_EGFR_Count, dt = p["time step"])
    sim.toSave(EGF_EGFR2_Count, dt=p["time step"])
    sim.toSave(EGF_EGFRp2_Count, dt = p["time step"])
    sim.toSave(EGF_EGFRp2_GAP_Count, dt = p["time step"])
    sim.toSave(ERKp_Count, dt = p["time step"])
    #sim.toSave(Xa_Origin, dt = p["time step"])
    sim.toSave(ERKpp_Count, dt = p["time step"])
    #sim.toSave(slice_ERKp, dt = p["time step"])
    #sim.toSave(slice_ERKpp, dt = p["time step"])
    #sim.toSave(surf_rec_com, dt = p["time step"])

    i = sys.argv[1]

    EGF_EGFR_Count.toFile(f"saved objects/Einzelne Runs/EGF-EGFR_sph_{p_name}_{factor}_{i}.dat")
    EGF_EGFR2_Count.toFile(f"saved objects/Einzelne Runs/EGF-EGFR2_sph_{p_name}_{factor}_{i}.dat")
    EGF_EGFRp2_Count.toFile(f"saved objects/Einzelne Runs/EGF-EGFRp2_sph_{p_name}_{factor}_{i}.dat")
    EGF_EGFRp2_GAP_Count.toFile(f"saved objects/Einzelne Runs/EGF-EGFRp2-GAP_sph_{p_name}_{factor}_{i}.dat")
    ERKp_Count.toFile(f"saved objects/Einzelne Runs/ERKp_sph_{p_name}_{factor}_{i}.dat")
    #Xa_Origin.toFile(f"saved objects/Einzelne Runs/Xa_Origin_sph_{p_name}_{factor}_{i}.dat")
    ERKpp_Count.toFile(f"saved objects/Einzelne Runs/ERKpp_sph_{p_name}_{factor}_{i}.dat")
    #slice_ERKp.toFile(f"saved objects/Einzelne Runs/slice_ERKp_sph_{p_name}_{factor}_{i}.dat")
    #slice_ERKpp.toFile(f"saved objects/Einzelne Runs/slice_ERKpp_sph_{p_name}_{factor}_{i}.dat")
    #surf_rec_com.toFile(f"saved objects/Einzelne Runs/surf_rec_com_sph_{p_name}_{factor}_{i}.dat")

    for r in range(1):

        sim.newRun()
        #sim.exo.EGF.Count = p["EGF0"] * ratio_v
        sim.TETS(tips_one).EGF.Count = p["EGF0"]/len(tips_one)
        print("EGF in exo: " + str(sim.exo.EGF.Count))
        sim.cell_surface.EGFR.Count = 5e4
        print("EGFR on membrane: " + str(sim.cell_surface.EGFR.Count))
        sim.cyt.GAP.Count = 1.2e4
        print("GAP in cytoplasm: " + str(sim.cyt.GAP.Count))
        sim.cyt.ERK.Count = 2.1e4 #6.3e7
        sim.cyt.P3.Count = 1e3#1.5e5
        sim.nuc_mem.ERKp.DiffusionActive = True
        start = time.time()
        sim.run(endt)
        end = time.time()
        print("Durchlaufzeit: " + str(end - start))

    return

#standard parameterssqueue
p = {"DC" : 4e-12, "k[666]" : 0.3, "k[0]" : 1e8, "time step" : 0.01, "EGF0": 1e4}

#FOR PARAMETERS
#factor = sys.argv[2]
#factor = factor.replace(",", ".")
#factor = float(factor)

#parameter = sys.argv[3]
#endt = 10

#value = p[parameter] * factor

#create_model(p | {parameter: value}, parameter, factor, endt)

#FOR NORMAL
parameter = "tips_one"
endt = 10
create_model(p, parameter, 1, endt)

#%%
import math
import numpy as np
def volume(r):

    V = 4/3  * math.pi *  r**(3)

    return V

def ober(r):

    o = 4 * math.pi * r**(2)

    return o

def radius(V):

    r = ((3*V)/(4*math.pi))**(1/3)

    return r

print(radius(1765-88))
print(ober(7.4))
def volume_cylinder(r, h):

    V = math.pi * r**2 * h

    return V
def ober_cylinder(r,h):

    O = math.pi * 2 * r *(r+h)

    return O
print(ober_cylinder(2,7))

def radius_eli(bc):

    V = volume(4.4)
    b = bc
    c = bc
    a = (3*V)/(4*b*c*math.pi)

    return a
alla = []
for i in np.arange(4.5, 7.6, 0.1):
    a = radius_eli(i)
    alla.append(a)


EGFR_0 = 5e4
GAP_0 = 1.2e4
ERK_0 = 2.1e7
P3_0 = 1e7
EGF_0 = 1e4
V_0 = 1e-15 #m^3
O_0 = 7e-15 #m^2
V_sph_eli = volume(7.5) * 1e-18 #m^3
O_sph = ober(7.5) * 1e-12 #m^3
O_eli = 1237e-12  #m^3

EGFR_sph = EGFR_0/O_0 * O_sph
EGFR_eli = EGFR_0/O_0 * O_eli
GAP_sph = GAP_0/V_0 * V_sph_eli
ERK_sph = ERK_0/V_0 * V_sph_eli
P3_sph = EGFR_0/V_0 * V_sph_eli

def D(r):

    k_b = 1.38e-23 #J/K
    T = 20+273.15 #K
    n = 1e-3 #N*s/m^2
    D = (k_b*T)/(6*math.pi*n*r)

    return D

def upper(D, k, A):

    N = 6.022e23 #1/mol

    up = ((108*D)/(10*math.sqrt(2)*k*N*A))**(1/5)

    return up

def lower(D,k):
    N = 6.022e23  # 1/mol
    low = (10 * k)/(N*D)

    return low
N = 6.022e23
#r1_up = upper(0.4e-12, 3e7, EGFR_0/(V_sph_eli*N), EGF_0/(V_sph_eli*N))
#r1_low = lower(0.4e-12, 3e7)
#print(f"r1: {r1_low} < h < {r1_up}")
r3_up = upper(0.1e-12, 1e3, 10/(V_sph_eli*N))
r3_low = lower(0.1e-12, 1e3)
print(f"r3: {r3_low} < h < {r3_up}")
def ra():

    A = 1765
    b = 10
    a = A/(b*math.pi)

    return a

def finger(r, h):

    v1 = volume_cylinder(r, h)
    V = 1765
    r1 = radius(V-v1)

    return r1