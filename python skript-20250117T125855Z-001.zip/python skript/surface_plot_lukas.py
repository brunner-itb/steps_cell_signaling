import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
import numpy as np
from matplotlib import pyplot as plt
import matplotlib
import pandas as pd
from collections import Counter
import seaborn as sns
import csv
import scipy

#type = "finger"
#t=15
type = "eli1"
#t=5
x = np.load(f"saved objects/dens/surf_rec_com_{type}_dens_1_5.npy")
dist = np.load(f"saved objects/dens/dist_surf_{type}.npy")
area = np.load(f"saved objects/dens/tris_area_{type}.npy")

#%%

def my_bins(d):
    #Ellipsoid
    #if d < 9:
    #    return 1
    #if d > 8.9 and d < 13:
    #    return 2
    #if d > 12.9 and d < 17:
    #    return 3
    #if d > 16.9:
    #    return 4

    #Ellipsoid
    if d < 15:
        return 1
    if d > 15:
        return 2

    #Finger
    #if d < 7.2:
    #    return 1
    #if d > 7.2 and d < 12:
    #    return 2
    #if d > 12 and d < 18:
    #    return 3
    #if d > 18:
    #    return 4

    #Finger
    #if d < 7.2:
    #    return 1
    #if d > 7.2:
    #    return 2

indices = list(np.ndindex(x.shape[:2]))
df_list = []
for i,(run_index, time_index) in enumerate(indices):
    df = pd.DataFrame(x[run_index,time_index],columns = ["count"])
    df["run_index"] = run_index
    df["time_index"] = time_index
    df["area"] = area * 1e12
    df["dist"] = dist * 1e6
    df["bin"] = df["dist"].apply(my_bins)
    df = df.groupby(["bin","run_index","time_index"]).sum().reset_index()
    df["density"] = df["count"]/df["area"]


    df_list.append(df)
    print(i/len(indices) * 100)


full_df = pd.concat(df_list)
full_df.index = pd.RangeIndex(len(full_df))
full_df["time_index"] = full_df["time_index"].apply(lambda x: x*0.01)
full_df.round({"time_index":2})
full_df.to_csv(f"superior_df_{type}_2.csv")
# %%
type = "finger"
full_df = pd.read_csv(f"superior_df_{type}_2.csv")
#sns.lineplot(x = "time_index", y = "density", hue ="bin", data = full_df)
#plt.show()
#plt.savefig("Plots/surface/lineplot.pdf")
#%%
fig = plt.figure(figsize=(3, 2.5))
df = full_df.loc[full_df["time_index"].isin((2, 3, 4, 5))]
sns.barplot(data = df, x= "time_index", y = "density",  hue = "bin", errorbar = "sd", palette = "Set2")
plt.xlabel("Time [s]", fontsize = 12)
plt.ylabel(r"(EGF-EGFR$^p$)$_2$-GAP/μm$^2$", fontsize = 12)
#plt.legend(("body", "tips"), fontsize=12)
plt.savefig(f"Plots/surface/barplot_{type}_gross_2.pdf", bbox_inches="tight")
plt.show()
#df = full_df.loc[full_df["time_index"].isin((0.5, 1, 1.5))]
#ax = sns.barplot(data = df, x= "time_index", y = "density",  hue = "bin", errorbar = "sd", palette = "Set2")
#ax.set(xlabel = "Time [s]", ylabel = "Particle/μm^2")
#plt.savefig(f"Plots/surface/barplot_{type}_klein_2.pdf", bbox_inches="tight")
#plt.show()
#%%
import seaborn as sns
sns.lineplot(data = full_df, x = "time_index", y = "density", hue = "bin", errorbar= "sd")
plt.show()


#%%
df_test = pd.DataFrame()
p_value = []
shap1 = []
shap2 = []
fold = []
time = []

for t in np.unique(full_df["time_index"]):
    sub_df = full_df.loc[(full_df["time_index"] == t)]
    r = scipy.stats.ttest_ind(
        sub_df.loc[(sub_df["bin"] == 1), "density"], sub_df.loc[(sub_df["bin"] == 2), "density"],
        equal_var=False
    )
    if r.pvalue <= 0.01:

        time.append(t)
        p_value.append(r.pvalue)
        shap1.append(scipy.stats.shapiro(sub_df.loc[(sub_df["bin"] == 1),"density"]).statistic)
        shap2.append(scipy.stats.shapiro(sub_df.loc[(sub_df["bin"] == 2),"density"]).statistic)

        try:
            fold.append(np.log2(sub_df.loc[(sub_df["bin"] == 1),"density"].mean()/sub_df.loc[(sub_df["bin"] == 2),"density"].mean()))
        except ZeroDivisionError:
            fold.append(np.nan)

df_test["t-test p-value"] = p_value
df_test["shapiro bin1"] = shap1
df_test["shapiro bind4"] = shap2
df_test["log2 fold_change"] = fold
df_test.index = time

df_test.to_csv(f"test_for_{type}_2.csv")