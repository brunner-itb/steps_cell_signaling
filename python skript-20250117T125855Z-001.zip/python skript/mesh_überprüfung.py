import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
import os
import numpy as np
import pandas as pd

#%%

mdl = Model()
#mesh = TetMesh.LoadAbaqus('meshes/finger_0.45.inp', scale = 1.01e-6)
mesh = TetMesh.LoadAbaqus(f'meshes/elipsoid_4.5-ext.inp', scale = 10**(-6))
#mesh = TetMesh.LoadAbaqus(f'meshes/kugel_7.5-ext.inp', scale = 10**(-6))
#type = "Elipsoid"
#mesh = TetMesh.LoadAbaqus("meshes/hexa2.inp", scale = 1e-6)

with mdl:
    vsys = VolumeSystem.Create()
    exo_vsys = VolumeSystem.Create()
    vsys_nuc = VolumeSystem.Create()
    ssys = SurfaceSystem.Create()

with mesh:

    # EXO
    exo_tets = TetList(mesh.tetGroups["Volume1"])

    # Zelle
    cyt_tets = TetList(mesh.tetGroups["Volume2"])

    # Zellkern
    nuc_tets = TetList(mesh.tetGroups["Volume3"])

    # Zellkern
    nuc = Compartment.Create(nuc_tets, vsys_nuc)

    # Cytoplasma
    cyt = Compartment.Create(cyt_tets, vsys)

    # Zelläüßeres

    exo = Compartment.Create(exo_tets, exo_vsys)

    cell_surface = Patch.Create(cyt.surface & exo.surface, cyt, exo, ssys)

    nuc_mem = DiffBoundary.Create(nuc.surface)

    #left_exo = [tet for tet in exo_tets if np.linalg(tet.center) < 0]
    #dist = [np.linalg.norm(tet.center) for tet in left_exo]
    #index_max_dist = np.argmax(np.array(dist))
    #tip = exo_tets[index_max_dist]

    cell_surface_left = [tri for tri in cell_surface.tris if tri.center.z < 0]
    cell_surface_top = [tri for tri in cell_surface.tris if tri.center.x > 0]
    dist_cell_surface_left = [np.linalg.norm(tri.center) for tri in cell_surface_left]
    dist_cell_surface_top = [np.linalg.norm(tri.center) for tri in cell_surface_top]

    max_left = np.max(dist_cell_surface_left)
    min_top = np.min(dist_cell_surface_top)

    wanted_left = 1e-6 + max_left
    wanted_top = 1e-6 + min_top

    dist_exo = [np.linalg.norm(tet.center) for tet in exo_tets]

    wanted_value_left = min(dist_exo, key=lambda x: abs(x - wanted_left))
    wanted_index_left = dist_exo.index(wanted_value_left)
    wanted_value_top = min(dist_exo, key=lambda x: abs(x - wanted_top))
    wanted_index_top = dist_exo.index(wanted_value_top)

    tet_left = exo_tets[wanted_index_left]
    tet_top = exo_tets[wanted_index_top]



    #bin1_v = TetList(tet for tet in cyt_tets if np.linalg.norm(tet.center) < 15e-6)#< 7.2e-6)
    #bin2_v = TetList(tet for tet in cyt_tets if np.linalg.norm(tet.center) > 15e-6)#> 7.2e-6)

    #bin1_s = bin1_v.surface & exo.surface
    #bin2_s = bin2_v.surface & exo.surface

    #ratio1 = bin1_s.Area/bin1_v.Vol
    #ratio2 = bin2_s.Area/bin2_v.Vol

    #print(ratio1)
    #print(ratio2)

#%%
cyt_left = [tet for tet in cyt_tets if tet.center.z < 0]
cyt_right = [tet for tet in cyt_tets if tet.center.z > 0]
cell_surface_left = [tri for tri in cell_surface.tris if tri.center.z < 0]
cell_surface_right = [tri for tri in cell_surface.tris if tri.center.z > 0]

dist_cyt_left = [np.linalg.norm(tet.center) for tet in cyt_left]
dist_cyt_right = [np.linalg.norm(tet.center) for tet in cyt_right]
dist_cell_surface_left = [np.linalg.norm(tri.center) for tri in cell_surface_left]
dist_cell_surface_right = [np.linalg.norm(tri.center) for tri in cell_surface_right]

max_left = np.max(dist_cell_surface_left)
max_right = np.max(dist_cell_surface_right)

wanted_left = 1e-6 + max_left
wanted_right = 1e-6 + max_right

dist_exo = [np.linalg.norm(tet.center) for tet in exo_tets]

wanted_value_left = min(dist_exo, key = lambda x:abs(x-wanted_left))
wanted_index_left = dist_exo.index(wanted_value_left)
wanted_value_right = min(dist_exo, key = lambda x:abs(x-wanted_right))
wanted_index_right = dist_exo.index(wanted_value_right)

left = exo_tets[wanted_index_left]
right = exo_tets[wanted_index_right]

#%%
#bins
dist = np.load(f"saved objects/dens/dist_surf_finger.npy")

bin1 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] < 7.2e-6), mesh = mesh)
bin2 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 7.2e-6 and dist[i] < 12e-6 ), mesh = mesh)
bin3 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 12e-6 and dist[i] < 18e-6), mesh = mesh)
bin4 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 18e-6), mesh = mesh)
#%%
dist = np.load(f"saved objects/dens/dist_surf_eli1.npy")

bin1 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] < 9e-6), mesh = mesh)
bin2 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 8.9e-6 and dist[i] < 13e-6 ), mesh = mesh)
bin3 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 12.9e-6 and dist[i] < 17e-6), mesh = mesh)
bin4 = TriList((tris for i,tris in enumerate(cell_surface.tris) if dist[i] > 16.9e-6), mesh = mesh)
#%%

import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

def plotTriangles(ax, tris, color):
    ax.add_collection(Poly3DCollection(
        [tri.verts for tri in tris],
        facecolor=color,
        edgecolors='black',
        linewidth=0.1
    ))

fig = plt.figure(figsize=(10, 10))
ax = fig.add_subplot(projection='3d')

plotTriangles(ax, tet_left.faces, "red")
plotTriangles(ax, tet_top.faces, "red")
plotTriangles(ax, cyt.surface, (0.1, 0.2, 0.5, 0.09))

ax.view_init(elev=0, azim=0, roll=0)
ax.set_xlim(mesh.bbox.min.x, mesh.bbox.max.x)
ax.set_ylim(mesh.bbox.min.y, mesh.bbox.max.y)
ax.set_zlim(mesh.bbox.min.z, mesh.bbox.max.z)
ax.set_xlabel('x position [m]')
ax.set_ylabel('y position [m]')
ax.set_zlabel('z position [m]')
ax.set_aspect('equal')
#plt.savefig(f"Plots/surface/3D_hexa2.pdf")
plt.show()
#%%
#### the same but only for the cell surface ###

def stats_surf_mesh(mesh, scale):
    # for sph,eli, finger_0.45

    mesh = TetMesh.LoadAbaqus(f'meshes/{mesh}.inp', scale=scale)

    tris_surf = mesh.tetGroups["Volume2"].surface & mesh.tetGroups["Volume1"].surface
    tris_amount = len(tris_surf)
    tris_surface_areas = [tris.Area for tris in tris_surf]
    tris_surface_areas = np.array(tris_surface_areas) * 1e12

    exo = mesh.tetGroups["Volume1"]
    cyt = mesh.tetGroups["Volume2"]
    nuc = mesh.tetGroups["Volume3"]

    exo_Vol = exo.Vol * 1e18
    cyt_Vol = cyt.Vol * 1e18
    nuc_Vol = nuc.Vol * 1e18


    return tris_surface_areas, tris_amount, exo_Vol, cyt_Vol, nuc_Vol

#Sphere and Finger
#meshes = ["kugel_7.5", "elipsoid_4.5", "finger_0.45"]
meshes = ["hexa1", "hexa2"]
scales = [1e-6, 1e-6]

#Sphere in different sizes
#meshes = ["kugel_7.5", "sph_0.3", "sph_0.4", "sph_0.5", "sph_1.0"]
#scales = [1e-6, 1e-6, 1e-6, 1e-6, 1e-6]

df = pd.DataFrame()
comp = pd.DataFrame()
amounts = []

for m,s in zip(meshes, scales):

    x, y, exo, cyt, nuc = stats_surf_mesh(m,s)
    x = pd.DataFrame({f"tris of {m}":x})
    df = pd.concat([df,x], axis = 1)
    amounts.append(y)

    comp[f"{m}"] = [exo, cyt, nuc]


stats = pd.DataFrame()
stats["means"] = df.mean(skipna=True)
stats ["std"] = df.std(skipna=True)
stats["max"] = df.max(skipna=True)
stats["min"] = df.min(skipna=True)
stats["amount"] = amounts
stats.to_csv(f"stats_meshes_surface-{meshes}.csv")

comp.to_csv(f"compartment_volumes_{meshes}.csv")

#%%
#Volumes of Compartments


