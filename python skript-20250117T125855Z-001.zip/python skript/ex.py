import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
from matplotlib import pyplot as plt
import numpy as np
import math
import os
import time


if os.getcwd() != '/home/anna3171/annas-magnificent-steps-project':

    os.chdir(r"/home/anna3171/annas-magnificent-steps-project")

def putti(file_name, first_folder, second_folder, endt, runs, file_name_save):


    all = []
    for i in range(1,runs+1):

        data = ResultSelector.FromFile(f"saved objects/Einzelne Runs/{file_name}_{i}.dat")
        data_np = np.array(data.data[0])
        all.append(data_np)
        print(i)

        #print(data_np.shape)

    all_np = np.dstack(all)
    all_np = np.rollaxis(all_np, -1)
    #print(all_np.shape)

    np.save(f"saved objects/{first_folder}/{second_folder}/{file_name_save}_{endt}", all_np)
    print(f"saved objects/{first_folder}/{second_folder}/{file_name_save}_{endt}.dat")

def putti_more(file_name, dir, folder, endt):

    all = []
    for i in range(1,10):
        data = ResultSelector.FromFile(f"saved objects/{folder}/{file_name}_{i}.dat")
        #print(f"saved objects/Einzelne Runs/{file_name}_{i}.dat")
        data_np = np.array(data.data[0])
        all.append(data_np)

    all_np = np.dstack(all)
    all_np = np.rollaxis(all_np, -1)
    # print(all_np.shape)

    data2 = np.load(f"saved objects/Parameter runs/{dir}/{file_name}_{endt}.npy")

    joined_data = np.concatenate((data2, all_np))
    np.save(f"saved objects/Parameter runs/{dir}/{file_name}_{endt}_20", joined_data)
    print(f"saved {file_name}_{endt}")


    return

#for normal run
#endt = 5
#names = ("ERK_bin1", "ERKp_bin1", "ERK_bin2", "ERKp_bin2", "ERK_bin3", "ERKp_bin3", "ERK_bin4", "ERKp_bin4")
#names = ("ERK_bin1", "ERKp_bin1", "ERK_bin2", "ERKp_bin2", "surf_rec_com")
#for n in names:
#    putti(f"{n}_finger_dens_1", "dens", "ERK", endt, 100)

#values = np.logspace(-1,1,20)
#values = np.round(values, 2)



#NORMAL RUNS
endt = 10
type = "eli1_4.5"
parameter = "tet_top"
folder = "exp"
names = ("EGF-EGFR", "EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKpp", "ERKp")#,
#names = ("GAP_Finger", "GAP_Body")
for n in names:
    putti(f"{n}_{type}_{parameter}_1", folder, parameter, endt, 100, f"{n}_{type}_{parameter}_1")

#endt = 10
#type = "finger"
#putti(f"EGFR_{type}_exp_EGFR_1","exp", "EGFR", endt, 100, f"EGFR_{type}_exp")




#%%

def repair(type):

    for d in dir:
        for n in names:
            for j in (0.1, 1.0):

                x = np.load(f"saved objects/Parameter runs/{d}/{n}_{type}_{d}_{j}_30.npy")
                np.save(f"saved objects/Parameter runs/{d}/{n}_{type}_{d}_{j}_5.npy", x)
                print(f"saved objects/Parameter runs/{d}/{n}_{type}_{d}_{j}_5.npy")
    return

names = ("EGF-EGFR", "EGF-EGFRp2", "nuc_Count", "Xa_Count") #,"Xa_Origin")
dir = ("DCR", "DCX", "k[0]", "k[666]")

repair("sph")
#%%
#Daten mit metadata

x = ResultSelector.FromFile(f"saved objects/Einzelne Runs/slice_ERKp_eli1_dens_1_1.dat")
trisInds_cyt = x.metaData["surfTri"]
np.save("saved objects/dens/trisInds_cyt_eli1.npy", trisInds_cyt)
x = ResultSelector.FromFile(f"saved objects/Einzelne Runs/slice_ERKpp_eli1_dens_1_1.dat")
trisInds_nuc = x.metaData["surfTri"]
np.save("saved objects/dens/trisInds_nuc_finger.npy", trisInds_nuc)
#%%
type = "finger"
x = ResultSelector.FromFile(f"saved objects/Einzelne Runs/EGFR_{type}_exp_EGFR_1_1.dat")
dist = x.metaData["dist"]
area = x.metaData["area"]
np.save(f"saved objects/exp/EGFR/dist_surf_{type}_exp.npy", dist)
np.save(f"saved objects/exp/EGFR/tris_area_{type}_exp.npy", area)

#%%
import numpy as np
def normal_runs(runs, file_name, save_name, folder, endt):
    all = []
    for i in range(1,runs+1):

        data = ResultSelector.FromFile(f"saved objects/Einzelne Runs/{file_name}_{i}.dat")
        data_np = np.array(data.data[0])
        print(f"{i}")
        all.append(data_np)

    all_np = np.dstack(all)
    all_np = np.rollaxis(all_np, -1)

    np.save(f"saved objects/{folder}/{save_name}_{endt}.npy", all_np)
    print(f"{file_name}_{i}.dat")

#for n in ("EGF-EGFR", "EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKp", "ERKpp"):

    #normal_runs(10, f"{n}_sph_mesh_1.0", f"{n}_sph_mesh_1.0","test", 10)
    #normal_runs(100, f"{n}_finger_test_1", f"{n}_finger_test_1", "test", 15)
#normal_runs(100, "slice_ERKpp_eli1_dens_1", "dens", 5)
normal_runs(10, "surf_rec_com_finger_dens_1", "surf_rec_com_finger_dens_1", "dens", 15)



