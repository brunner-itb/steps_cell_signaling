import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
from collections import Counter
import seaborn as sns
import csv
import scipy

#names = ("ERK_bin1", "ERKp_bin1", "ERK_bin2", "ERKp_bin2", "ERK_bin3", "ERKp_bin3", "ERK_bin4", "ERKp_bin4")
names = ("ERK_bin1", "ERKp_bin1", "ERK_bin2", "ERKp_bin2")
full_df = pd.DataFrame()
df_list = []
time = np.arange(0,501)
time = time * 0.01

for n in names:
    data = np.load(f"saved objects/dens/ERK/{n}_finger_dens_1_5.npy")
    data_avg = np.mean(data, axis=0)
    df = pd.DataFrame(data_avg)
    df_list.append(df)

full_df = pd.concat(df_list, axis = 1)
full_df.columns = names
#full_df["ERK_bin1+2"] = full_df["ERK_bin1"] + full_df["ERK_bin2"]
#full_df["ERK_bin3+4"] = full_df["ERK_bin3"] + full_df["ERK_bin4"]
#full_df["ERKp_bin1+2"] = full_df["ERKp_bin1"] + full_df["ERKp_bin2"]
#full_df["ERKp_bin3+4"] = full_df["ERKp_bin3"] + full_df["ERKp_bin4"]



df_plot = pd.DataFrame()

for i in (1,2):#("1+2","3+4"):

    df_plot[f"ERKp/ERK bin{i} % "] = full_df[f"ERKp_bin{i}"]/full_df[f"ERK_bin{i}"] * 100

df_plot["time"] = time
#%%
#plot
#legend = ["body", "tips"]
legend = ["body", "protrusion"]
type = "Protr." #"Ellipsoid"
colors = ["seagreen", "coral"]
labels = [""]
fig = plt.figure(figsize=(3, 2.5))
col = ("ERKp/ERK bin1 % ", "ERKp/ERK bin2 % ")
for z,i in enumerate(col):
    sns.lineplot(data = df_plot, x = "time", y = i, color = colors[z], label = legend[z])#["seagreen", "coral"])
plt.xlabel("Time [s]", fontsize = 12)
plt.ylabel(r"ERK$^p$ to ERK ratio in %", fontsize = 12 )
plt.legend(fontsize=12)
plt.savefig(f"Plots/ERK/ERKp-ERK_{type}.pdf", bbox_inches="tight")
plt.show()


#%%
df_test = pd.DataFrame()
p_value = []
shap1 = []
shap2 = []
fold = []
time = []

for t in np.unique(full_df["time_index"]):
    sub_df = full_df.loc[(full_df["time_index"] == t)]
    r = scipy.stats.ttest_ind(
        sub_df.loc[(sub_df["bin"] == 1), "density"], sub_df.loc[(sub_df["bin"] == 4), "density"],
        equal_var=False
    )
    if r.pvalue <= 0.01:

        time.append(t)
        p_value.append(r.pvalue)
        shap1.append(scipy.stats.shapiro(sub_df.loc[(sub_df["bin"] == 1),"density"]).statistic)
        shap2.append(scipy.stats.shapiro(sub_df.loc[(sub_df["bin"] == 4),"density"]).statistic)

        try:
            fold.append(np.log2(sub_df.loc[(sub_df["bin"] == 1),"density"].mean()/sub_df.loc[(sub_df["bin"] == 4),"density"].mean()))
        except ZeroDivisionError:
            fold.append(np.nan)

df_test["t-test p-value"] = p_value
df_test["shapiro bin1"] = shap1
df_test["shapiro bind4"] = shap2
df_test["log2 fold_change"] = fold
df_test.index = time

df_test.to_csv(f"test_for_{type}_4.csv")