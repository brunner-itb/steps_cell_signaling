import steps.interface
from steps.model import *
from steps.geom import *
from steps.rng import *
from steps.sim import *
from steps.saving import *
from steps.visual import *
from matplotlib import pyplot as plt
import numpy as np
import math
import os
import seaborn as sns
import statistics as st
import pandas as pd
from matplotlib.colors import ListedColormap


if os.getcwd() != '/home/anna3171/annas-magnificent-steps-project':

    os.chdir(r"/home/anna3171/annas-magnificent-steps-project")

########################
#COUNTS ÜBER TIME PLOTS
#######################
def re(data, type):

    time = len(data[0])
    new_data = np.zeros(time)
    for i in range(len(data)):
        x = data[i]
        listi = []
        for j in range(time):
            listi.append(x[j][0])
        new_data = np.vstack([new_data, listi])

    new_data = np.delete(new_data, 0, 0)
    #print(new_data.shape)
    return new_data

def nuc_count_plot_single(nuc_count1,n, type, dir, parameter, i, ylabel, endt1, endt2, endtt, label):

    try:

        x = np.load(f"saved objects/{dir}/{parameter}/{n}_{type}_{parameter}_{i}_{endt1}.npy")
    except FileNotFoundError:
        x = np.load(f"saved objects/{dir}/{parameter}/{n}_{type}_{parameter}_{i}_{endt2}.npy")


    time = len(x[0])
    runs = len(x)

    early = []
    for r in range(runs):
        count_i = nuc_count1[r]
        for j in range(time):
            if count_i[j] > 0:
                early.append(j)
                break

    early_mean_sph = np.mean(early, axis=0)
    early_mean_sph = early_mean_sph * 0.01

    nuc_count1 = re(nuc_count1, "sph")
    counts1 = np.nanmean(nuc_count1, axis = 0)
    t = int(endtt/0.01)
    counts1 = counts1[0:t]
    std1 = np.nanstd(nuc_count1, axis = 0)
    std1 = std1[0:t]

    x = np.arange(len(counts1))
    x = x * 0.01


    plt.fill_between(x, counts1+std1, counts1-std1, alpha=.3, linewidth=0)
    plt.plot(x, counts1, lw = 2, ms = 2, label = f"{label}")#, label = f"{i} ({early_mean_sph:.2f} s)")
    #plt.vlines(early_mean_sph,0, 400, lw = 2, label = f"mean time {i}" )
    plt.xlabel("Time [s]", fontsize = 12)
    plt.ylabel(f"{ylabel}", fontsize = 12)
    plt.legend(loc = "upper left", fontsize = 10)
    #plt.title(f"{ylabel} - {endtt}")
    plt.tight_layout()

    return
def nuc_plot(names, types, dir, parameter, i_list, endt1, endt2, endtt, title, label, ylabels, plot_folder):

    fig = plt.figure(figsize=(7, 4))
    for z, n in enumerate(names):
        ylabel = ylabels[z]
        plt.subplot(2,3,z+1)

        for l,t in enumerate(types):


            i = i_list[l]

            para = parameter[l]

            try:

                nuc_count = np.load(f"saved objects/{dir}/{para}/{n}_{t}_{para}_{i}_{endt1}.npy")
            except FileNotFoundError:
                nuc_count = np.load(f"saved objects/{dir}/{para}/{n}_{t}_{para}_{i}_{endt2}.npy")

            nuc_count_plot_single(nuc_count, n,t, dir, para, i, ylabel, endt1, endt2, endtt, label[l])

    plt.savefig(f"Plots/{plot_folder}/{endtt}-{label}.pdf", bbox_inches="tight")
    plt.show()

################################
#normal plot
################################

def normi_single(nuc_count1,n, type, dir, parameter, i, ylabel, endt1, endt2, endtt):

    try:

        x = np.load(f"saved objects/{dir}/{n}_{type}_{parameter}_{i}_{endt1}.npy")
    except FileNotFoundError:
        x = np.load(f"saved objects/{dir}/{n}_{type}_{parameter}_{i}_{endt2}.npy")


    time = len(x[0])
    runs = len(x)

    early = []
    for r in range(runs):
        count_i = nuc_count1[r]
        for j in range(time):
            if count_i[j] > 0:
                early.append(j)
                break

    early_mean_sph = np.mean(early, axis=0)
    early_mean_sph = early_mean_sph * 0.01

    nuc_count1 = re(nuc_count1, "sph")
    counts1 = np.nanmean(nuc_count1, axis = 0)
    t = int(endtt/0.01)
    counts1 = counts1[0:t]
    std1 = np.nanstd(nuc_count1, axis = 0)
    std1 = std1[0:t]

    x = np.arange(len(counts1))
    x = x * 0.01


    plt.fill_between(x, counts1+std1, counts1-std1, alpha=.3, linewidth=0)
    plt.plot(x, counts1, lw = 2, ms = 2)#, label = f"{i} ({early_mean_sph:.2f} s)")
    #plt.vlines(early_mean_sph,0, 400, lw = 2, label = f"mean time {i}" )
    plt.xlabel("Time [s]", fontsize = 12)
    plt.ylabel(f"{ylabel}", fontsize = 12)
    #plt.legend(loc = "upper left", fontsize = 10)
    #plt.title(f"{ylabel} - {endtt}")
    plt.tight_layout()

    return

def normi(names, type, dir, parameter, i, endt1, endt2, endtt, title, ylabels):

    fig = plt.figure(figsize=(7, 4))
    for z, n in enumerate(names):
        ylabel = ylabels[z]
        plt.subplot(2,3,z+1)

        try:

            nuc_count = np.load(f"saved objects/{dir}/{n}_{type}_{parameter}_{i}_{endt1}.npy")
        except FileNotFoundError:
            nuc_count = np.load(f"saved objects/{dir}/{n}_{type}_{parameter}_{i}_{endt2}.npy")

        normi_single(nuc_count, n, type, dir, parameter, i, ylabel, endt1, endt2, endtt)

    plt.savefig(f"Plots/{parameter}/{endtt}-{type}.pdf", bbox_inches="tight")
    plt.show()
###########################
##PARAMETER PLOT for one parameter and one mesh
##############################

def barabara(parameter, type, value, name, endt, ylabel, title):

    nuc_count1 = np.load(f"saved objects/Parameter runs/{parameter}/{name}_{type}_{parameter}_{value}_{endt}.npy")

    time = len(nuc_count1[0])
    runs = len(nuc_count1)

    early = []
    for r in range(runs):
        count_i = nuc_count1[r]
        for j in range(time):
            if count_i[j] > 0:
                early.append(j)
                break

    early_mean_sph = np.mean(early, axis=0)
    early_mean_sph = early_mean_sph * 0.01

    endt = int(endt/0.01)
    nuc_count1 = re(nuc_count1, "sph")
    counts1 = np.nanmean(nuc_count1, axis = 0)
    std1 = np.nanstd(nuc_count1, axis = 0)
    std1 =std1[0:endt]
    counts1 = counts1[0:endt]

    x = np.arange(len(counts1))
    x = x * 0.01

    #plt.errorbar(x, counts1, yerr = std1,lw = 2, ms = 2, label = f"{i} ({early_mean_sph:.2f} s)")
    #plt.vlines(early_mean_sph,0, 400, lw = 2, label = f"mean time {i}" )
    plt.fill_between(x, counts1 + std1, counts1 - std1, alpha=.3, linewidth=0, label=f"{value}")
    plt.plot(x, counts1, lw=2, ms=2, label=f"{value} ({early_mean_sph:.2f} s)")
    # plt.vlines(early_mean_sph,0, 400, lw = 2, label = f"mean time {i}" )
    plt.xlabel("Time [s]")
    plt.ylabel(f"{ylabel}")
    plt.legend(loc = "upper left", fontsize = 11)
    plt.title(f"{title}")

    return

def barbara(parameter, type, values, name, endt, ylabel, title):

    for v in values:

        barabara(parameter, type, v, name, endt, ylabel, title)

    plt.savefig(f"Plots/Parameters/{parameter}/{title}.pdf", bbox_inches="tight")
    plt.show()
    return



#%%
names = ("EGF-EGFR", "EGF-EGFR2","EGF-EGFRp2","EGF-EGFRp2-GAP", "ERKp", "ERKpp") #,"Xa_Origin")
#names = ("GAP_Body", "GAP_Finger")
endt1 = 100
endt2 = 100
endtt = 100
#type = "finger" #"eli1_4.5"
type = "sph"
dir = "test"
parameter = "test"
i = 1
#ylabel = ("GAP in Body", "GAP in Finger")
ylabel = ("EGF-EGFR ", r"(EGF-EGFR)$_2$",r"(EGF-EGFR$^p$)$_2$",r"(EGF-EGFR$^p$)$_2$-GAP", r"ERK$^p$(cyt)", r"ERK$^p$(nuc)")


normi(names, type, dir, parameter, i, endt1, endt2, endtt, "", ylabel)



#%%

#COUNT PLOTS
names = ("EGF-EGFR", "EGF-EGFR2","EGF-EGFRp2","EGF-EGFRp2-GAP", "ERKp", "ERKpp")
#parameter = ("test", "test", "test")
parameter = ("tet_left", "tet_top")
types = ("eli1_4.5", "eli1_4.5") #("sph", "eli1_4.5", "finger") #("sph", "eli1_4.5","finger")
ylabels = ("EGF-EGFR ", r"(EGF-EGFR)$_2$",r"(EGF-EGFR$^p$)$_2$",r"(EGF-EGFR$^p$)$_2$-GAP", r"ERK$^p$(cyt)", r"ERK$^p$(nuc)")
i_list = (1,1)
label = ("Ellipsoid-left", "Ellipsoid-top")#("Sphere-ext", "Ellipsoid-ext", "Finger")
plot_folder = "tips_one"
endt1 = 10
endt2 = 15
endtt = 10
nuc_plot(names, types, "exp", parameter, i_list, endt1, endt2, endtt, f"{endtt} s",
         label, ylabels, plot_folder)

#%%
#for mesh size
#COUNT PLOTS
names = ("EGF-EGFR", "EGF-EGFR2","EGF-EGFRp2","EGF-EGFRp2-GAP", "ERKp", "ERKpp")
parameter = ("mesh", "test", "mesh", "mesh")
i_list = (0.3, 1, 0.5, 1.0)
ylabels = ("EGF-EGFR ", r"(EGF-EGFR)$_2$",r"(EGF-EGFR$^p$)$_2$",r"(EGF-EGFR$^p$)$_2$-GAP", r"ERK$^p$(cyt)", r"ERK$^p$(nuc)")
endt1 = 10
endt2 = 15
endtt = 10
nuc_plot(names, ("sph", "sph", "sph", "sph"), "test", parameter, i_list,  endt1, endt2, endtt,
         f"Sphere with different mesh sizes", ("0.3", "0.4", "0.5", "1.0"),ylabels)
#%%
#Plot für einen Factor von Parameter
parameter = "EGF0"
n = "EGF-EGFRp2-GAP"
types = ("sph", "eli1_4.5")
factor = 10.0
endtt = 10
fig = plt.figure(figsize=(3,3))
for t in types:

    data = np.load(f"saved objects/Parameter runs/{parameter}/{n}_{t}_{parameter}_{factor}_{endtt}.npy")

    data = re(data, "sph")
    data_avg = np.nanmean(data, axis=0)
    t = int(endtt / 0.01)
    data_avg = data_avg[0:t]
    std1 = np.nanstd(data, axis=0)
    std1 = std1[0:t]

    x = np.arange(len(data_avg))
    x = x * 0.01

    plt.fill_between(x, data_avg + std1, data_avg - std1, alpha=.3, linewidth=0)
    plt.plot(x, data_avg, lw=2, ms=2, label=f"{t}")
    plt.xlabel("Time [s]", fontsize=12)
    plt.ylabel(f"{n} count", fontsize=12)
    # plt.legend(loc = "upper left", fontsize = 10)
    # plt.title(f"{ylabel} - {endtt}")
    plt.tight_layout()

plt.savefig(f"Plots/Parameters/{parameter}/{n}_{factor}.pdf", bbox_inches="tight")
plt.show()



#%%
#BOXPLOTS

names = ("EGF-EGFR","EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKp", "ERKpp") #,"Xa_Origin")
dic_sph = extract("sph", names, "test")
dic_eli1 = extract("eli1_4.5", names, "test")
dic_eli2 = extract("eli2_4.5", names, "test")
for n in names:
    times_sph = dic_sph[f"{n} earliest time"]
    times_eli1 = dic_eli1[f"{n} earliest time"]
    times_eli2 = dic_eli2[f"{n} earliest time"]
    plt.boxplot((times_sph, times_eli1, times_eli2), labels = ("sph", "eli1", "eli2"))
    plt.title(f"{n}")
    plt.ylabel("time of first appearance [s]")
    plt.savefig(f"Plots/Parameters/test/boxplot_{n}.pdf", bbox_inches="tight")
    plt.show()

#%%
#PARAMETER PLOTS per parameters
dic = {}
names = ("EGF-EGFR", "EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKp", "ERKpp")
values = np.logspace(-1,1,20)
values = np.round(values, 2)
dir = ("DC", "k[0]", "k[666]", "EGF0")
endt = 5
type = "sph"
dic = para_dic(dic,dir, names, type, values, endt)
ymax = y_max()


for n, y in zip(names, ymax):

    plotii(dic, n, type, values, dir, endt, y)
#%%
#PARAMETER PLOTS per DC

dic = {}
#names = ("EGF-EGFR", "EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKp", "ERKpp")
names = ("EGF-EGFRp2-GAP", "ERKpp")
values = np.logspace(-1,1,10)
values = np.round(values, 2)
#values = values[0:5]
dir = "DC"
endt = 3
types = ("sph", "eli1_4.5")#, "eli2_4.5")
dic = para_dic_DC(dic,dir, names, types, values, endt)

for n in names:

    plotii_DC(dic, n, types, values, dir, endt)

#%%
#PARAMETER PLOT fpr one parameter and one mesh

parameter = "DC"
type = "sph"
values = (0.001, 0.01, 0.1, 1.0)
names = ("EGF-EGFR", "EGF-EGFR2", "EGF-EGFRp2", "EGF-EGFRp2-GAP", "ERKp", "ERKpp")
endt = 10

for n in names:

    barbara(parameter, type, values, n, endt, f"{n}-Count", f"different initial {parameter} amount - {n} -{type}")
#%%
#HEATMAP

#EGF-EGFRp2-GAP

values = np.logspace(-1,1,10)
values = np.round(values, 2)
parameter = "EGF0"
df_list = []
time = np.arange(1001) * 0.01
time = np.round(time, 2)

for v in values:

    data = np.load(f"saved objects/Parameter runs/{parameter}/EGF-EGFRp2-GAP_sph_{parameter}_{v}_10.npy")
    data_avg = np.mean(data, axis = 0)
    df = pd.DataFrame(data_avg)
    df_list.append(df)

df_sph = pd.concat(df_list, axis = 1)
#full_df.columns = [str(v)+"- EGF-EGFRp2-GAP" for v in values]
df_sph.columns = [values]

df_list = []
for v in values:

    data = np.load(f"saved objects/Parameter runs/{parameter}/EGF-EGFRp2-GAP_eli1_4.5_{parameter}_{v}_10.npy")
    data_avg = np.mean(data, axis = 0)
    data_avg = data_avg[0:1001]
    df = pd.DataFrame(data_avg)
    df_list.append(df)

df_eli = pd.concat(df_list, axis = 1)
#full_df.columns = [str(v)+"- EGF-EGFRp2-GAP" for v in values]
df_eli.columns = [values]

df_eli_sph = pd.DataFrame()

for col in df_eli:
    df_eli_sph["sph - eli " + str(col)] = pd.Series(df_sph[col]-df_eli[col])

df_eli_sph.index = [time]

fig = plt.figure(figsize = (3,3))
xticks = values
cmap = plt.colormaps["rainbow"]
#cmap=ListedColormap(['black', 'red'])
sns.heatmap(df_eli_sph, xticklabels = xticks, cmap=cmap, cbar_kws={'label': r"Difference in (EGF-EGFR$^p$)$_2$-GAP"+" count \n(Sph-Eli)"})

plt.xlabel(f"{parameter} factor", fontsize = 12)
plt.ylabel(f"Time [s]", fontsize = 12)
plt.savefig(f"Plots/Parameters/{parameter}/heatmap_EGF-EGFRp2-GAP.pdf", bbox_inches="tight")
plt.show()
#%%
#ERKpp

values = np.logspace(-1,1,10)
values = np.round(values, 2)
parameter = "EGF0"
df_list = []
time = np.arange(1001) * 0.01
time = np.round(time, 2)

for v in values:

    data = np.load(f"saved objects/Parameter runs/{parameter}/ERKpp_sph_{parameter}_{v}_10.npy")
    data_avg = np.mean(data, axis = 0)
    data_avg = data_avg[0:1001]
    df = pd.DataFrame(data_avg)
    df_list.append(df)

df_sph = pd.concat(df_list, axis = 1)
#full_df.columns = [str(v)+"- EGF-EGFRp2-GAP" for v in values]
df_sph.columns = [values]

df_list = []
for v in values:

    data = np.load(f"saved objects/Parameter runs/{parameter}/ERKpp_eli1_4.5_{parameter}_{v}_10.npy")
    data_avg = np.mean(data, axis = 0)
    data_avg = data_avg[0:1001]
    df = pd.DataFrame(data_avg)
    df_list.append(df)

df_eli = pd.concat(df_list, axis = 1)
#full_df.columns = [str(v)+"- EGF-EGFRp2-GAP" for v in values]
df_eli.columns = [values]

df_eli_sph = pd.DataFrame()

for col in df_eli:
    df_eli_sph["sph - eli  " + str(col)] = pd.Series(df_sph[col]-df_eli[col])

df_eli_sph.index = [time]

fig = plt.figure(figsize = (3,3))
xticks = values
vmin = df_eli_sph.min()
vmax = df_eli_sph.max()
cmap = plt.colormaps["rainbow"]
#cmap=ListedColormap(['black', 'red'])
sns.heatmap(df_eli_sph, xticklabels = xticks, cmap=cmap, cbar_kws={'label': r"Difference in ERK$^p$(nuc)"+" count \n(Sph-Eli)"})#, center = 0)

plt.xlabel(f"{parameter} factor", fontsize = 12)
plt.ylabel(f"Time [s]", fontsize = 12)
plt.savefig(f"Plots/Parameters/{parameter}/heatmap_ERKpp.pdf", bbox_inches="tight")
plt.show()

